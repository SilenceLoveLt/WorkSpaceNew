package com.yyk.constant;
/**
* @author 作者 E-mail:
* @version 创建时间：2019年4月14日 下午12:07:47
* 类说明
*/
public interface Constants {

}
