package com.yyk.dto.BaseCodeDTO;

import java.util.List;

import com.yyk.entity.BaseCode;


/**
 * <P>Description: TODO</P>
 * @ClassName: basCode
 * @author lijing
 * @see
 */
public class BaseCodeResDTO extends BaseCode {

    private String enableName;

	public String getEnableName() {
		return enableName;
	}

	public void setEnableName(String enableName) {
		this.enableName = enableName;
	}

	
  
	
}
